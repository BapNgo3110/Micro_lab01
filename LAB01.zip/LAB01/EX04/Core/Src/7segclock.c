#include "main.h"
#include "7segclock.h"

#define NUMBER_OF_CLOCKS 2

uint8_t Buffer_7seg[NUMBER_OF_CLOCKS];
uint8_t Conv_7seg[10] = { 0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f,
		0x6f };

void Buffer_Update_7seg(uint8_t val, uint8_t idx) {
	Buffer_7seg[idx] = val;
}

void display7SEG(uint8_t idx) {
	uint8_t temp = Conv_7seg[Buffer_7seg[idx]];

	if (idx == 0) {
		if (temp & 0x01) {
			HAL_GPIO_WritePin(A_GPIO_Port, A_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(A_GPIO_Port, A_Pin, SET);
		}

		if (temp & 0x02) {
			HAL_GPIO_WritePin(B_GPIO_Port, B_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(B_GPIO_Port, B_Pin, SET);
		}

		if (temp & 0x04) {
			HAL_GPIO_WritePin(C_GPIO_Port, C_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(C_GPIO_Port, C_Pin, SET);
		}

		if (temp & 0x08) {
			HAL_GPIO_WritePin(D_GPIO_Port, D_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(D_GPIO_Port, D_Pin, SET);
		}

		if (temp & 0x10) {
			HAL_GPIO_WritePin(E_GPIO_Port, E_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(E_GPIO_Port, E_Pin, SET);
		}

		if (temp & 0x20) {
			HAL_GPIO_WritePin(F_GPIO_Port, F_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(F_GPIO_Port, F_Pin, SET);
		}

		if (temp & 0x40) {
			HAL_GPIO_WritePin(G_GPIO_Port, G_Pin, RESET);
		} else {
			HAL_GPIO_WritePin(G_GPIO_Port, G_Pin, SET);
		}
	}

}
