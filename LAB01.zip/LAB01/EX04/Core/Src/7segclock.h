/*
 * 7segclock.h
 *
 *  Created on: Mar 26, 2024
 *      Author: PC
 */

#ifndef INC_7SEGCLOCK_H_
#define INC_7SEGCLOCK_H_

void Buffer_Update_7seg(uint8_t val, uint8_t idx);
void display7SEG(uint8_t idx);


#endif /* INC_7SEGCLOCK_H_ */
